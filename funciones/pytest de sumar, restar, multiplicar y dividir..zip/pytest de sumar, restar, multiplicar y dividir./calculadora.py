def sum_numbers(number1, number2):
    return number1 + number2

#def is_greater_than(number1, number2):